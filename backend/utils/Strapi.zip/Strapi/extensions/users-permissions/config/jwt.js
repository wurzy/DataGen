module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'df1642ee-bb13-4088-ab78-3afc0641a4fa'
};